﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Shop_app
{
    public partial class onchest : Form
    {
        public NpgsqlConnection con;
        int id;
        int id_client;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        public void Update()
        {
            String sql = "Select * from onchest";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dg.DataSource = dt;
            dg.Columns[0].HeaderText = "Номер";
            dg.Columns[1].HeaderText = "Дата";
            dg.Columns[2].HeaderText = "Имя клиента";
            dg.Columns[3].HeaderText = "Суммарная стоимость";
            this.StartPosition = FormStartPosition.CenterScreen;
            List <Client> list = new List <Client>();
            string request = "select id, name from client";
            NpgsqlCommand com = new NpgsqlCommand(request, con);
            using (NpgsqlDataReader reader = com.ExecuteReader())
            {
                while (reader.Read())
                {
                    string str = reader["id"].ToString();
                    int id_c = Convert.ToInt32(str);
                    string name = reader["name"].ToString();
                    Client client = new Client(id_c, name);
                    list.Add(client);
                }
            }
            comboBox1.DataSource = list;
            comboBox1.DisplayMember = "Name";
            comboBox1.ValueMember = "id";
        }
        public onchest(NpgsqlConnection con)
        {
            this.con = con;
            InitializeComponent();
            Update();
        }


        private void dg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dg_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection selectedRows = dg.SelectedRows;
            if (selectedRows.Count > 0)
            {
           
            }
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void добавитьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            NpgsqlCommand command = new NpgsqlCommand("INSERT INTO client (dt1.date,id_client,0) VALUES (:dt1.date, :id_client, 0)", con);
            Update();
        }

        private void обновитьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            
        }

        private void удалитьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            string message = "Вы точно хотите удалить?";
            string caption = "Подтверждение операции";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                int id = (int)dg.CurrentRow.Cells["ID"].Value;
                NpgsqlCommand command = new NpgsqlCommand("Delete from tovar where ID = :id", con);
                command.Parameters.AddWithValue("id", id);
                command.ExecuteNonQuery();
                Update();
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        public class Client
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public Client(int id, string name)
                { this.Id = id; this.Name = name; }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Client client = (Client)comboBox1.SelectedItem;
            id_client = client.Id;
        }

        private void onchest_Load(object sender, EventArgs e)
        {

        }
    }
}
