﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace WindowsFormWithDataBase
{
    public partial class Form1 : Form
    {
        public NpgsqlConnection npgsqlConnection;
        public void Load()
        {
            this.StartPosition = FormStartPosition.CenterScreen;
            npgsqlConnection = new NpgsqlConnection("Server=localhost; Port=5432; UserID=postgres; Password=postpass; Database=Eto Baza");
            npgsqlConnection.Open();
           
        }
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs eventArgs)
        {
           
            Load();
            if (npgsqlConnection != null)
                MessageBox.Show("ok");
            else
                MessageBox.Show("not ok");

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form2 formProduct = new Form2(npgsqlConnection);
            formProduct.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
